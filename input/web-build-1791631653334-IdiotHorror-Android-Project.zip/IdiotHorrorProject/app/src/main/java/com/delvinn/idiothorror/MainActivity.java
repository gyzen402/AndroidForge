package com.delvinn.idiothorror;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.LinearLayout;
import java.util.Random;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private final Random random = new Random();
    private FrameLayout root;
    private TextView face, title, subtitle;
    private boolean running = true;
    private int tick = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        TextView safety = new TextView(this);
        safety.setText("PRANK SIMULATION — NO VIRUS");
        safety.setTextColor(0xFFAAAAAA);
        safety.setTextSize(12);
        safety.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams safetyParams = new FrameLayout.LayoutParams(-1, dp(38), Gravity.TOP);
        root.addView(safety, safetyParams);

        face = new TextView(this);
        face.setText("☺");
        face.setTextColor(Color.YELLOW);
        face.setTextSize(100);
        face.setGravity(Gravity.CENTER);
        face.setTypeface(Typeface.DEFAULT_BOLD);
        FrameLayout.LayoutParams faceParams = new FrameLayout.LayoutParams(dp(180), dp(180), Gravity.CENTER);
        root.addView(face, faceParams);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams labelParams = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        labelParams.topMargin = dp(48);
        root.addView(labels, labelParams);

        title = new TextView(this);
        title.setText("YOU ARE AN IDIOT");
        title.setTextColor(Color.RED);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        labels.addView(title);

        subtitle = new TextView(this);
        subtitle.setText("HAHAHAHAHAHA");
        subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        labels.addView(subtitle);

        Button stop = new Button(this);
        stop.setText("STOP PRANK");
        stop.setTextColor(Color.WHITE);
        stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB00020));
        FrameLayout.LayoutParams stopParams = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        stopParams.bottomMargin = dp(28);
        root.addView(stop, stopParams);
        stop.setOnClickListener(v -> stopPrank());

        setContentView(root);
        animate();
    }

    private void animate() {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!running) return;
                tick++;
                int maxX = Math.max(1, root.getWidth() - dp(180));
                int maxY = Math.max(1, root.getHeight() - dp(360));
                face.setX(random.nextInt(maxX));
                face.setY(dp(100) + random.nextInt(maxY));
                face.setRotation(random.nextInt(31) - 15);
                title.setTextColor(tick % 2 == 0 ? Color.RED : 0xFFFF6680);
                subtitle.setText(tick % 2 == 0 ? "HAHAHAHAHAHA" : "YOU ARE AN IDIOT");
                root.setBackgroundColor(tick % 2 == 0 ? Color.BLACK : 0xFF100000);
                handler.postDelayed(this, 450);
            }
        }, 450);
    }

    private void stopPrank() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        root.removeAllViews();
        root.setBackgroundColor(Color.BLACK);
        LinearLayout end = new LinearLayout(this);
        end.setOrientation(LinearLayout.VERTICAL);
        end.setGravity(Gravity.CENTER);
        end.setPadding(dp(24), dp(24), dp(24), dp(24));
        TextView msg = new TextView(this);
        msg.setText("TENANG BRO! 😂\n\nIni cuma simulasi prank. Tidak ada virus.\n\nJangan sembarangan menginstal APK dari sumber tidak dikenal.");
        msg.setTextColor(Color.WHITE);
        msg.setTextSize(20);
        msg.setGravity(Gravity.CENTER);
        end.addView(msg);
        Button exit = new Button(this);
        exit.setText("KELUAR");
        exit.setOnClickListener(v -> finish());
        end.addView(exit);
        root.addView(end, new FrameLayout.LayoutParams(-1, -1));
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onBackPressed() {
        if (running) stopPrank(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
